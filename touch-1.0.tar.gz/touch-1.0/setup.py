from setuptools import setup, find_packages

setup(
    name='touch',
    version='1.0',
    entry_points={
        'console_scripts': [
            'touch = touch.main:main',
        ],
    },
    packages=find_packages(),
    install_requires=[
        'click',
        'requests'
    ],
)
