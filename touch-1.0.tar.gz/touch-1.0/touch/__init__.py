# touch/__init__.py

from .touch import main

__all__ = ['main']
